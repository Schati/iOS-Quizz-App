//
//  ViewController.swift
//  QuizApp
//
//  Created by Dominik on 12.07.21.
//

import UIKit




class ViewController: UIViewController {
    
    //MARK: - Outlets
    
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var answerButton1: UIButton!
    @IBOutlet weak var answerButton2: UIButton!
    //@IBOutlet weak var answerButton3: UIButton!
    @IBOutlet weak var questionCountLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var progressBarView: UIView!
    
    
    
    // MARK: - Variables
    var questions = [Question]()
    var questionNumber = 0
    public var score = 0
    var messageIT = AdvisoryMessageIT.message
    var messageDK = AdvisoryMessageDK.message
    var messageNO = AdvisoryMessageNO.message
    var messageGR = AdvisoryMessageGR.message
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        setupButton()
    
    //MARK: API Precall
        let url1 = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=NO"
       
        let url2 = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=IT"
        let url3 = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=GR"
        let url4 = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=DK"
        
        
        let url5 = "https://www.travel-advisory.info/api?countrycode=IT"
        let url6 = "https://www.travel-advisory.info/api?countrycode=NO"
        let url7 = "https://www.travel-advisory.info/api?countrycode=GR"
        let url8 = "https://www.travel-advisory.info/api?countrycode=DK"
       
        getDataSecondIT(from: url5)
        getDataSecondNO(from: url6)
        getDataSecondGR(from: url7)
        getDataSecondDK(from: url8)
        
        getData(from: url1)
        getData(from: url2)
        getData(from: url3)
        getData(from: url4)
        
        //MARK: QUESTION/ANSWERS Func
        createQuestionObjects()
        
        questionLabel.text = questions[0].questionText
        answerButton1.setTitle(questions[0].answer1, for: .normal)
        answerButton2.setTitle(questions[0].answer2, for: .normal)
        //answerButton3.setTitle(questions[0].answer3, for: .normal)
        
        scoreLabel.text = "Score: 0"
        questionCountLabel.text = "1 / \(questions.count)"
        
    
    
    }
    //MARK: - Setup Button
    func setupButton() {
        // Tag vergeben
        answerButton1.tag = 1
        answerButton2.tag = 2
        //answerButton3.tag = 3
        
        answerButton1.layer.cornerRadius = 20
        answerButton1.layer.borderWidth = 2
        answerButton1.layer.borderColor = UIColor.black.cgColor
        
        answerButton2.layer.cornerRadius = 20
        answerButton2.layer.borderWidth = 2
        answerButton2.layer.borderColor = UIColor.black.cgColor
        
        //answerButton3.layer.cornerRadius = 20
        //answerButton3.layer.borderWidth = 2
        //answerButton3.layer.borderColor = UIColor.black.cgColor
        
    }
    
    
    @IBAction func answerButton_Tapped(_ sender: UIButton) {
        let answerTag = sender.tag
        
        checkAnswer(answerTag: answerTag)
        
        nextQuestion()
    }
    
    func checkAnswer(answerTag: Int) {
        if answerTag == questions[questionNumber].correctAnswerTag {
            print ("Positiv")
            score += 2
        } else {
            print ("Negativ")
            score += 1
        }
        questionNumber += 1
    }
    
    func nextQuestion() {
        if questionNumber < questions.count {
            questionLabel.text = questions[questionNumber].questionText
            answerButton1.setTitle(questions[questionNumber].answer1, for: .normal)
            answerButton2.setTitle(questions[questionNumber].answer2, for: .normal)
            //answerButton3.setTitle(questions[questionNumber].answer3, for: .normal)
            
            updateUI()
        } else {
            self.performSegue(withIdentifier: "resultGame", sender: self.score)
            self.view.showBlurLoader()
        }
    }

    func restart() {
        questionNumber = 0
        score = 0
        questionCountLabel.text = "1 / \(questions.count)"
        nextQuestion()
    }

// MARK: display score
func updateUI() {
    scoreLabel.text = "Score: \(score)"
    questionCountLabel.text = "\(questionNumber + 1) / \(questions.count)"
    let widthIphone = self.view.frame.size.width
    let widthProgressCountView = Int(widthIphone) / questions.count
    
    progressBarView.frame.size.width = CGFloat(widthProgressCountView * (questionNumber + 1))
    
}

//MARK: - Create question objects

func createQuestionObjects() {
    let question1 = Question(text: "Do you prefer a warm climate?")
    question1.answer1 = "Yes"
    question1.answer2 = "No"
    //question1.answer3 = "Antwort3"
    question1.correctAnswerTag = 1
    
    let question2 = Question(text: "Should it be an inexpensive vacation?")
    question2.answer1 = "Yes"
    question2.answer2 = "No"
    //question2.answer3 = "Antwort3"
    question2.correctAnswerTag = 1
    
    let question3 = Question(text: "Do you travel alone?")
    question3.answer1 = "Yes"
    question3.answer2 = "No"
    //question3.answer3 = "Antwort3"
    question3.correctAnswerTag = 1
    
    let question4 = Question(text: "Would you like to travel longer than one week?")
    question4.answer1 = "Yes"
    question4.answer2 = "No"
    //question4.answer3 = "Antwort3"
    question4.correctAnswerTag = 1
    
    let question5 = Question(text: "Do you want to bring pets?")
    question5.answer1 = "Yes"
    question5.answer2 = "No"
    //question5.answer3 = "Antwort3"
    question5.correctAnswerTag = 1
    
    let question6 = Question(text: "Hotel?")
    question6.answer1 = "Yes"
    question6.answer2 = "No"
    //question6.answer3 = "Antwort3"
    question6.correctAnswerTag = 1
    
    let question7 = Question(text: "Do you prefer a beach vacation?")
    question7.answer1 = "Yes"
    question7.answer2 = "No"
    //question7.answer3 = "Antwort3"
    question7.correctAnswerTag = 1
    
    let question8 = Question(text: "Do you want to get to know foreign cultures?")
    question8.answer1 = "Yes"
    question8.answer2 = "No"
    //question8.answer3 = "Antwort3"
    question8.correctAnswerTag = 1
    
    let question9 = Question(text: "Do you like culinary travel?")
    question9.answer1 = "Yes"
    question9.answer2 = "No"
    //question1.answer3 = "Antwort3"
    question9.correctAnswerTag = 1
    
    let question10 = Question(text: "Do you like leisure activities?")
    question10.answer1 = "Yes"
    question10.answer2 = "No"
    //question2.answer3 = "Antwort3"
    question10.correctAnswerTag = 1
    
    let question11 = Question(text: "Are you afraid of flying?")
    question11.answer1 = "Yes"
    question11.answer2 = "No"
    //question3.answer3 = "Antwort3"
    question11.correctAnswerTag = 1
    
    let question12 = Question(text: "Summer vacation?")
    question12.answer1 = "Yes"
    question12.answer2 = "No"
    //question4.answer3 = "Antwort3"
    question12.correctAnswerTag = 1
    
    let question13 = Question(text: "Do you like party holidays?")
    question13.answer1 = "Yes"
    question13.answer2 = "No"
    //question5.answer3 = "Antwort3"
    question13.correctAnswerTag = 1
    
    let question14 = Question(text: "Do you like a wellness vacation?")
    question14.answer1 = "Yes"
    question14.answer2 = "No"
    //question6.answer3 = "Antwort3"
    question14.correctAnswerTag = 1
    
    let question15 = Question(text: "Is this app worth a grade 1?")
    question15.answer1 = "Yes"
    question15.answer2 = "Yes, of Course"
    //question7.answer3 = "Antwort3"
    question15.correctAnswerTag = 1
    
    questions.append(question1)
    questions.append(question2)
    questions.append(question3)
    questions.append(question4)
    questions.append(question5)
    questions.append(question6)
    questions.append(question7)
    questions.append(question8)
    questions.append(question9)
    questions.append(question10)
    questions.append(question11)
    questions.append(question12)
    questions.append(question13)
    questions.append(question14)
    questions.append(question15)
    
}
    //MARK: API PRECALL
    
    
    
    
    //MARK: API CORONA NUMBERS
    
    func getData(from url: String) {
       
       let task = URLSession.shared.dataTask(with: URL(string: url)!, completionHandler: { data, response, error in
           
           guard let data = data, error == nil else {
               print ("something went wrong")
               return
           }
           // data
           var latest: Response?
           do {
               latest = try JSONDecoder().decode(Response.self, from: data)
           }
           catch {
               print ("failed to convert \(error.localizedDescription)")
           }
           
           guard let json = latest else {
               return
           }
           
           
           print ("Confirmed:\(json.latest.confirmed)")
           print("Recovered: \(json.latest.recovered)")
           print("Deaths: \(json.latest.deaths)")
           
           LabelDisplay.confirmed = Int(json.latest.confirmed)
           LabelDisplay.recovered = Int(json.latest.recovered)
           LabelDisplay.deaths = Int(json.latest.deaths)

       })
       
       task.resume()
        
        
   }
    //MARK: API ADVISORY MESSAGE
    
    
    
    //MARK: ITALY
    private func getDataSecondIT(from url5: String) {
        
        let task = URLSession.shared.dataTask(with: URL(string: url5)!, completionHandler: { data, response, error in
            
            guard let data = data, error == nil else {
                print ("something went wrong")
                return
            }
            // data
            var advisory: ResponseIT?
            do {
                advisory = try JSONDecoder().decode(ResponseIT.self, from: data)
            }
            catch {
                print ("failed to convert \(error.localizedDescription)")
            }
            
            guard let json = advisory else {
                return
            }
            
            
            print (json.data.IT.advisory.message)
            AdvisoryMessageIT.message = json.data.IT.advisory.message
        
        })
        
        task.resume()
    }
    
    //MARK: GREECE
    private func getDataSecondGR(from url7: String) {
        
        let task = URLSession.shared.dataTask(with: URL(string: url7)!, completionHandler: { data, response, error in
            
            guard let data = data, error == nil else {
                print ("something went wrong")
                return
            }
            // data
            var advisory: ResponseGR?
            do {
                advisory = try JSONDecoder().decode(ResponseGR.self, from: data)
            }
            catch {
                print ("failed to convert \(error.localizedDescription)")
            }
            
            guard let json = advisory else {
                return
            }
            
            
            print (json.data.GR.advisory.message)
            AdvisoryMessageGR.message = json.data.GR.advisory.message
            
        })
        
        task.resume()
    }
    //MARK: DENMARK
    
    private func getDataSecondDK(from url8: String) {
        
        let task = URLSession.shared.dataTask(with: URL(string: url8)!, completionHandler: { data, response, error in
            
            guard let data = data, error == nil else {
                print ("something went wrong")
                return
            }
            // data
            var advisory: ResponseDK?
            do {
                advisory = try JSONDecoder().decode(ResponseDK.self, from: data)
            }
            catch {
                print ("failed to convert \(error.localizedDescription)")
            }
            
            guard let json = advisory else {
                return
            }
            
            
            print (json.data.DK.advisory.message)
            AdvisoryMessageDK.message = json.data.DK.advisory.message
            
        })
        
        task.resume()
    }
    //MARK: NORWAY
    private func getDataSecondNO(from url6: String) {
        
        let task = URLSession.shared.dataTask(with: URL(string: url6)!, completionHandler: { data, response, error in
            
            guard let data = data, error == nil else {
                print ("something went wrong")
                return
            }
            // data
            var advisory: ResponseNO?
            do {
                advisory = try JSONDecoder().decode(ResponseNO.self, from: data)
            }
            catch {
                print ("failed to convert \(error.localizedDescription)")
            }
            
            guard let json = advisory else {
                return
            }
            
            
            print (json.data.NO.advisory.message)
            AdvisoryMessageNO.message = json.data.NO.advisory.message
            
        })
        
        task.resume()
    }
    //MARK: score/api segue to resultViewcontroller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! resultViewController
        vc.questionscore = score
        vc.messagePassedIT = AdvisoryMessageIT.message
        vc.messagePassedNO = AdvisoryMessageNO.message
        vc.messagePassedGR = AdvisoryMessageGR.message
        vc.messagePassedDK = AdvisoryMessageDK.message
    }
    
    
    
}
