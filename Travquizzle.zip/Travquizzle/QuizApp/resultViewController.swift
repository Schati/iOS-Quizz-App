//
//  resultViewController.swift
//  QuizApp
//
//  Created by Dominik on 24.08.21.
//

import UIKit
import MapKit

class resultViewController: UIViewController, CLLocationManagerDelegate {

    var questionscore = 0
    var nameCountry = ""
    var latitudeCountry: Double = 0.00
    var longitudeCountry: Double = 0.00
    var countryID = ""
    var messagePassedIT = ""
    var messagePassedNO = ""
    var messagePassedGR = ""
    var messagePassedDK = ""
   
    
   //MARK: OUTLETS
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var restartButton: UIButton!
    
    @IBOutlet weak var resultcountryLabel: UILabel!
    
    @IBOutlet weak var CNumber: UILabel!
    
    @IBOutlet weak var RNumber: UILabel!
    
    @IBOutlet weak var DNumber: UILabel!
    
    @IBOutlet weak var AdvisoryMessageLabel: UILabel!
    
    //MARK: LOADVIEW
   
    override func loadView() {
        
        
        super.loadView()
        outputLandName()

        outPutMessage()
        
        let url = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=\(countryID)"
        
        getData(from: url)
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    //MARK: VIEWDIDAPPEAR
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
        resultcountryLabel.text = nameCountry
        CNumber.text = String(LabelDisplay.confirmed)
        RNumber.text = String(LabelDisplay.recovered)
        DNumber.text = String(LabelDisplay.deaths)
        
    
        
        
        //MARK: setup Buttons:
        restartButton.layer.cornerRadius = 20
        restartButton.layer.borderWidth = 2
        restartButton.layer.borderColor = UIColor.black.cgColor
        
    
        //MARK: set mapview location
        let location = CLLocationCoordinate2D(latitude: latitudeCountry, longitude: longitudeCountry)
        let region = MKCoordinateRegion(center: location, span: MKCoordinateSpan(latitudeDelta: 12, longitudeDelta: 12))
        
        self.mapView.setRegion(region, animated: true)
        
        
    }
    

    //MARK: Func outputLandName
    func outPutMessage() {
        switch questionscore {
        case 15...18:
            print ("case1")
            AdvisoryMessageLabel.text = messagePassedDK
            countryID = "DK"
        case 20...24:
            print ("case2")
            AdvisoryMessageLabel.text = messagePassedNO
            countryID = "NO"
        case 26...29:
            print ("case3")
            AdvisoryMessageLabel.text = messagePassedIT
            countryID = "IT"
        default:
            print ("case4")
            AdvisoryMessageLabel.text = messagePassedGR
            countryID = "GR"
        }
    }
    func outputLandName() {
        switch questionscore {
        case 15...18:
            nameCountry = "Denmark"
            latitudeCountry = 56.26
            longitudeCountry = 9.50
            self.view.showBlurLoader()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.getData(from: CountryFunctionDK.url)
                self.view.removeBluerLoader() }
        case 20...24:
            nameCountry = "Norway"
            latitudeCountry = 64.57
            longitudeCountry = 17.88
            self.view.showBlurLoader()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.getData(from: CountryFunctionNO.url)
                self.view.removeBluerLoader()                }
        case 26...29:
            nameCountry = "Italy"
            latitudeCountry = 41.29
            longitudeCountry = 12.57
            self.view.showBlurLoader()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.getData(from: CountryFunctionIT.url)
                self.view.removeBluerLoader() }
        default:
            nameCountry = "Greece"
            latitudeCountry = 38.27
            longitudeCountry = 23.81
            self.view.showBlurLoader()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.getData(from: CountryFunctionGR.url)
                self.view.removeBluerLoader() }
            
        }
    }
    
    
    // MARK: Restart Button
    @IBAction func restartButtonTapped(_ sender: UIButton) {
        self.performSegue(withIdentifier: "restartGame", sender: nil)
        questionscore = 0
        LabelDisplay.confirmed = 0
        LabelDisplay.deaths = 0
        LabelDisplay.recovered = 0
        AdvisoryMessageIT.message = ""
        AdvisoryMessageNO.message = ""
        AdvisoryMessageGR.message = ""
        AdvisoryMessageDK.message = ""
        messagePassedDK = ""
        messagePassedNO = ""
        messagePassedGR = ""
        messagePassedIT = ""
        nameCountry = ""
        countryID = ""
        latitudeCountry = 0.00
        longitudeCountry = 0.00
    }
    
    // MARK: API Func Corona Numbers
     func getData(from url: String) {
        
        let task = URLSession.shared.dataTask(with: URL(string: url)!, completionHandler: { data, response, error in
            
            guard let data = data, error == nil else {
                print ("something went wrong")
                return
            }
            var latest: Response?
            do {
                latest = try JSONDecoder().decode(Response.self, from: data)
            }
            catch {
                print ("failed to convert \(error.localizedDescription)")
            }
            
            guard let json = latest else {
                return
            }
            print ("Confirmed:\(json.latest.confirmed)")
            print("Recovered: \(json.latest.recovered)")
            print("Deaths: \(json.latest.deaths)")
            
            LabelDisplay.confirmed = Int(json.latest.confirmed)
            LabelDisplay.recovered = Int(json.latest.recovered)
            LabelDisplay.deaths = Int(json.latest.deaths)
        })
        task.resume()
    }
   


}







