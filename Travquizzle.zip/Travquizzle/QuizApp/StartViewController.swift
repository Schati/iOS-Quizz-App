//
//  StartViewController.swift
//  QuizApp
//
//  Created by Dominik on 24.08.21.
//
import MapKit
import UIKit



class StartViewController: UIViewController {

    // Mark: - Outlet
    
    
    @IBOutlet weak var startButton: UIButton!
    
    
//--------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //setup Buttons
        startButton.layer.cornerRadius = 20
        startButton.layer.borderWidth = 2
        startButton.layer.borderColor = UIColor.black.cgColor
        
        
    }
//--------------------------------
    
    @IBAction func startButtonTapped(_ sender: UIButton) {
        self.performSegue(withIdentifier: "startgame", sender: nil)
        
    }
    

}
