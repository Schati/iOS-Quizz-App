//
//  structs.swift
//  QuizApp
//
//  Created by Dominik on 31.08.21.
//

import Foundation


//MARK: ------------ API  Structs ----------------




//MARK: CORONA NUMBERS STRUCT

struct Response: Codable {
    let latest: MyResult
}

struct MyResult: Codable {
    let confirmed: Int
    let deaths: Int
    let recovered: Int
}

struct LabelDisplay {
    static var confirmed: Int = 0
    static var recovered: Int = 0
    static var deaths: Int = 0
}


//MARK: Advisory Message Struct:

struct AdvisoryMessageIT {
    static var message: String = ""
}
struct AdvisoryMessageGR {
    static var message: String = ""
}
struct AdvisoryMessageDK {
    static var message: String = ""
}
struct AdvisoryMessageNO {
    static var message: String = ""
}

//--------------IT-------
struct ResponseIT: Codable {
    let data: DataIT
}

struct DataIT: Codable {
    var IT: CountryCodeIT
}
struct CountryCodeIT: Codable {
    let advisory: AdvisoryIT
    }

struct AdvisoryIT: Codable {
    let message: String
    }
//---------GR-------
struct ResponseGR: Codable {
    let data: DataGR
}

struct DataGR: Codable {
    var GR: CountryCodeGR
}
struct CountryCodeGR: Codable {
    let advisory: AdvisoryGR
    }

struct AdvisoryGR: Codable {
    let message: String
    }
//---------DK-------
struct ResponseDK: Codable {
    let data: DataDK
}

struct DataDK: Codable {
    var DK: CountryCodeDK
}

struct CountryCodeDK: Codable {
    let advisory: AdvisoryDK
    }

struct AdvisoryDK: Codable {
    let message: String
    }

//---------NO-------
struct ResponseNO: Codable {
    let data: DataNO
}

struct DataNO: Codable {
    var NO: CountryCodeNO
}

struct CountryCodeNO: Codable {
    let advisory: AdvisoryDK
    }

struct AdvisoryNO: Codable {
    let message: String
    }


//MARK: URL´s Structs:

struct CountryFunctionIT {
static var url: String = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=IT"
static var urlm: String = "https://www.travel-advisory.info/api?countrycode=IT"
}

struct CountryFunctionDK {
static var url: String = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=DK"
static var urlm: String = "https://www.travel-advisory.info/api?countrycode=DK"
}

struct CountryFunctionNO {
static var url: String = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=NO"
static var urlm: String = "https://www.travel-advisory.info/api?countrycode=NO"
}

struct CountryFunctionGR {
static var url: String = "https://coronavirus-tracker-api.herokuapp.com/v2/locations?country_code=GR"
static var urlm: String = "https://www.travel-advisory.info/api?countrycode=GR"
}

